<?php


namespace Core;


class Loader extends Std
{
    protected static $documentRoot;

    /**
     * @return mixed
     */
    public static function getDocumentRoot()
    {
        return self::$documentRoot;
    }

    /**
     * @param mixed $documentRoot
     */
    public static function setDocumentRoot($documentRoot)
    {
        self::$documentRoot = $documentRoot;
    }


    public static function loadClass($className){

    }
    public static function requireClass($className){
        $classArray = explode('\\',$className);
        if(count($classArray) > 1){
            if(empty($classArray[0])){
                array_shift($classArray);
            }

        }
        $classFile = self::getDocumentRoot().'/src';
        foreach ($classArray as $classEl){
            $classFile .= '/'.$classEl;
        }
        $classFile .= '.php';
        try{
            require_once($classFile);
        }catch(\Exception $e){
            echo $e->getMessage();
        }

    }



}


