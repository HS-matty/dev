<?php


namespace Core\Type;


use Core\Std;

class Ui extends Std
{
    protected $size;

    /**
     * @return mixed
     */
    public function getSize()
    {
        return $this->size;
    }

    /**
     * @param mixed $size
     */
    public function setSize($size)
    {
        $this->size = $size;
    }


}