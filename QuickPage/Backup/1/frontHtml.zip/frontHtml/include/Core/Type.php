<?php


namespace Core;


class Type extends Std
{

}