<?php


namespace Core\Web\Grid;


use Core\Collection;

class Dataset extends Collection
{
    /**
     * @param $data
     */
    public function setData(array $data){

        return $this->setCollection(collect($data));
    }


    /**
     * @return \Illuminate\Support\Collection
     */
    public function getData(){
        return $this->collection();
    }
}