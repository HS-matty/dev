<?php
use Local\Config;
?>
<html>

<head>
    <title><?php echo $page->getTitle(); ?></title>
    <!-- Modernizr -->
    <script src="/js/libs/modernizr-2.6.2.min.js"></script>
    <!-- framework css -->
    <!--[if gt IE 9]><!-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <link type="text/css" rel="stylesheet" href="/css/groundwork.css">
    <!--<![endif]-->
    <!--[if lte IE 9]>
    <link type="text/css" rel="stylesheet" href="/css/groundwork-core.css">
    <link type="text/css" rel="stylesheet" href="/css/groundwork-type.css">
    <link type="text/css" rel="stylesheet" href="/css/groundwork-ui.css">
    <link type="text/css" rel="stylesheet" href="/css/groundwork-anim.css">
    <link type="text/css" rel="stylesheet" href="/css/groundwork-ie.css">
    <![endif]-->
</head>

<body>

<header>
    <div class="container">
        <div class="row">
            <div class="one half">
                <h1 class="quicksand">QuickPage</h1></div>
            <div class="one half"></div>
        </div>
    </div>
</header>

<!--  NAVIGATION -->
<div class="container">
    <nav class="nav gap-top" title="Menu" style="padding-left:10px">
        <div class="row">
            <div class="one half">
                <li><a href="<? echo Config::hostName();?>?page=Dashboard">Dashboard</a></li>
                <li><a href="<? echo Config::hostName();?>?page=Catalog">Catalog</a></li>
                <li><a href="<? echo Config::hostName();?>?page=Managers">Managers</a></li>

                </ul>
            </div>
        </div>

    </nav>
</div>
<!--  END_NAVIGATION -->


<!--  BODY -->


<div class="container">
    <div class="row">

        <div class="row" style="padding:15px">
            <div class="three fifths bounceInRight ">
                <h1 class="zero museo-slab"><h2><? echo $page->getTitle() ?></h2>
                    <p class="quicksand"><? echo $page->getDescription() ?></p>
            </div>
            <div class="two fifths align-right-ipad align-right-desktop flipInX animated">
                <p class="quicksand">Example Layout 1 of 4</p>
                <p><a href="home.html" rel="prev" class="blue button">Back</a> <a href="layout-b.html" rel="next"
                                                                                  class="green button">Next: Image
                        Gallery </a></p>
            </div>

        </div>

        <!--p class="success message">This is a success message.</p-->
        <hr/>

        <div class="container">
            <div class="row">
                <?php
                if ($pageFile) require_once($pageFile);
                else echo '<h1>Not Found</h1>';
                ?>
            </div>
        </div>

        <!--div id="message">
            <h3>TestMessage</h3>
        </div>


        <h1>Hello</h1>
        <button class="success">Success</button -->

    </div>
</div>


<script type="text/javascript" src="/js/libs/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="/js/groundwork.all.js"></script>

<!--  BODY -->

<footer class="gap-top bounceInUp">
    <div class="box square">
        <div class="container padded">
            <div class="row">
                <div class="one half padded">
                    Powered by QuickPage+:Accounting and PowerGroundworkCSS
                </div>
            </div>
        </div>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

</body>
</html>