<?php
use \Core\Web\Page;
/* @var $page Page */
/* @var $grid Core\Web\Grid */


$grid = $page->getUiElement('grid');
//dd($grid->getFields()->collection());
foreach ($grid->getFields() as $field){
    echo $field->getName();
}
?>
<?php
if(!$grid){
    echo 'No grid found';
}
?>
<br />
<h3><? echo $grid->getTitle(); ?></h3>
<table class="responsive" data-max="15">
    <thead>
    <tr>

        <? foreach ($grid->getFields()->collection() as $field): ?>
            <th><? echo $field->getTitle();?></th>
        <? endforeach; ?>
        <td>#</td>


    </tr>
    </thead>
    <tbody>
    <?  $dataset = $grid->getDataset(); ?>

    <? foreach ($dataset->getData()->all() as $row): ?>
        <tr>
            <? foreach ($row as $rowKey => $rowValue): ?>
                <? if(!$grid->inAllowedNamesByKey($rowKey)) continue;?>
                <td><? echo $rowValue;?></td>
            <? endforeach; ?>
            <td><a href="javascript:p_open(<? echo $row['__offset'];?>)"><i class="icon-twitter icon-4x"></i>
                </a></td>
        </tr>
    <? endforeach; ?>
    </tbody>
    <!--tfoot>
    <tr>
        <td>Footer cell</td>
        <td>Footer cell</td>
        <td>Footer cell</td>
        <td>Footer cell</td>
    </tr>
    </tfoot-->
</table>


<script type="application/javascript" >
    function p_open(id){
        //get table
        var Content;

                //$("#modal-content").innerText('test');
        //alert("tetst");
        $('#exampleModal').modal('show');
        $.get('<? echo \Local\Config::hostname(); ?>?page=Catalog_Form&id='+id,function (data){
            $('#modal-content').html(data);
        });




    }

</script>


<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="modal-content">
                Test
            </div>
            <div class="modal-footer">
                <!--button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button-->
            </div>
        </div>
    </div>
</div>

