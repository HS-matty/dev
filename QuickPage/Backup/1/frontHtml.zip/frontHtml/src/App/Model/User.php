<?php


namespace App\Model;
use App\Model as Model;

class User extends Model
{
    protected $table = ‘user’;

    public function initModel(){
        $this->addFillable([‘username’, ’email’, ’pass’]);
    }


}
