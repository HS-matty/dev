<?php


namespace Page;


class Dashboard extends \Core\Web\Page
{
    public function __construct(){
        $this->setName('Dashboard');
        $this->setTitle('Dashboard Central');
        $this->setDescription('Dashboard Central Description');
    }



}