<?php


namespace Page;
use League\Csv\Reader;
use Local\Config;
use Core\Web;
use Core\Ui\Element;

class Managers extends \Core\Web\Page
{
    public function __construct(){
        $this->setName('Managers');
        $this->setTitle('Managers');
        $this->setDescription('Managers');

        $grid = new Web\Grid();
        $grid->setName('grid');
        //

        //load the CSV document from a file path
        $csv = Reader::createFromPath(Config::rootDir().'/local/csv/b_user.csv', 'r');
        $csv->setHeaderOffset(0);

        $header = $csv->getHeader(); //returns the CSV header record
        $records = $csv->getRecords();


        $allowedNames = ["ID","TIMESTAMP_X","ACTIVE","NAME","LAST_NAME","EMAIL","LAST_LOGIN","DATE_REGISTER","LID","PERSONAL_PROFESSION","PERSONAL_WWW"];

       foreach ($header as $h){
           if(!in_array($h,$allowedNames)) continue;
           $field = $grid->addField();
           $field->setName($h)->setTitle($h);
           $this->addUiElement($grid);

       }

       //  //returns all the CSV records as an Iterator object

        //echo $csv->getContent(); //returns the CSV document as a string



        //
        //temporal ;D
        $arr = [];
        foreach ($csv->getRecords() as $key => $c ){
            $localArray = [];
            foreach ($allowedNames as $allowedName){
                if(isset($c[$allowedName])) {
                    $localArray[] = $c[$allowedName];
                }
            }
        $arr[] = $localArray;
        }



        //dd($arr);


        $dataset = new Web\Grid\Dataset();
        $dataset->setName('grid');

       /* $row1 = ['id'=>1,'name'=>'row1-name','value'=>'row1-value'];
        $row2 = ['id'=>2,'name'=>'row2-name','value'=>'row2-value'];
        $row3 = ['id'=>3,'name'=>'row3-name','value'=>'row3-value'];

        $data = [$row1,$row2,$row3];*/
        $data = [];
        $dataset->setData($arr);
        $grid->setDataset($dataset);


    }



}