<?php


namespace Page\Catalog;
use Core\Std;

class Form extends \Core\Web\Page
{

    public function __construct()
    {
        $this->setName('Catalog');
        $this->setTitle('Catalog');
        $this->setDescription('Catalog');
        $this->setBody((new Std('<h1>Item body</h1>')));
        $this->setIsSingleTrue();

    }
}