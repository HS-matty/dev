<?php
/* @var $page \Page\Catalog\Form */
?>
<h1>Form <? echo $page->getTitle();?></h1>

 <!--form action="#" method="post">
                <fieldset>
                    <legend>123<? echo $form->getTitle();?></legend>
<div class="row">
    <? foreach($form->getFields() as $field) { ?>
        <div class="one half padded">
            <label for="name"><? echo $field->getTitle();?></label>
            <input id="name" type="text" placeholder="<? echo $field->getDescription();?>">
        </div>
    <? }?>
</div>
</fieldset>
</form-->
