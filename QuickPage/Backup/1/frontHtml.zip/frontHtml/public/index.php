<?php

require_once('../include/boostrap.php');

use \Core\Request as Request;
use \Core\Globals as G;
use \Local\Config as Config;

use Illuminate\Support\Facades\DB;

//dd(DB::connection());
//$page = $request->input('page');

/*@todo validate*/
//$pageName = ucfirst(strtolower(substr(Request::input('page')->asString(),10)));
$pageName = ucfirst(substr(Request::input('page')->asString(), 0, 25));

$pageFile = null;
if ($pageName) {
    $pageNameArray = explode('_',$pageName);
    $pageClassName = "\\Page";
    foreach ($pageNameArray as $key =>  $pageNameValue){
     //   $pageNameValue = preg_replace("[^a-zA-Z]", $pageNameValue);
        $pageNameValue = ucfirst(strtolower($pageNameValue));
        $pageClassName .= "\\$pageNameValue";
    }
} else $pageClassName  = "\\Page\\Dashboard";

$pageFile = Config::publicDir().'/Doc'.$pageClassName.'.php';
//dd($pageFile);
if (!file_exists($pageFile)) $pageFile = 'Doc/Page/Dashboard.php';

//\Core\Loader::requireClass('\Page\Dashboard');

$page = new $pageClassName;
$form = new \Page\Dashboard\TestForm();

/* @var $page \Core\Web\Page */
if($page->isSingle()){
    require_once ($pageFile);
}else{
    require_once Config::srcDir()."/Template/Index.php";
}
exit();

