<?php


namespace Page;

use League\Csv\Reader;
use Local\Config;
use Core\Web;
use Core\Ui\Element;

class Managers extends \Core\Web\Page
{
    public function __construct()
    {
        $this->setName('Managers');
        $this->setTitle('Managers');
        $this->setDescription('Managers');

        $grid = new Web\Grid();
        $grid->setName('grid');

        $csv = \Core\Type\File\Csv::load('b_user.csv');


       // $allowedNames = ["ID", "TIMESTAMP_X", "ACTIVE", "NAME", "LAST_NAME", "EMAIL", "LAST_LOGIN", "DATE_REGISTER", "LID", "PERSONAL_PROFESSION", "PERSONAL_WWW"];
        $allowedNames = array ( 0 => 'ID', 1 => 'TIMESTAMP_X', 2 => 'ACTIVE', 3 => 'NAME', 4 => 'LAST_NAME', 5 => 'EMAIL', 6 => 'LAST_LOGIN', 7 => 'DATE_REGISTER', 8 => 'LID', 9 => 'PERSONAL_PROFESSION', 10 => 'PERSONAL_WWW');

        $grid->setAllowedNames($allowedNames);;

      //  var_export($allowedNames);
       // exit();
        foreach ($csv->getHeader() as $h) {

            if (!in_array($h, $allowedNames)) continue;
            $field = $grid->addField();
            $field->setName($h)->setTitle($h);
            $this->addUiElement($grid);

        }

        $collection = $csv->getData();
        $dataset = new Web\Grid\Dataset();
        $dataset->setName('grid');
        $dataset->setCollection($collection);

        $grid->setDataset($dataset);
    }


}