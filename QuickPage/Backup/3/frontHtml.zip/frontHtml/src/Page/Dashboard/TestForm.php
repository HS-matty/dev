<?php


namespace Page\Dashboard;

use Core\Type\Ui;

class TestForm extends \Core\Web\Form
{

    //function
    /**
     * TestForm constructor.
     */
    public function __construct()
    {

        //form params
        $this->setName('test form');
        $this->setTitle('test form');
        $this->setDescription('test form Description');

        //form elements
    //    $e = new \Core\Web\Form\Element();
     //   $e->setName('d');

     //   $field1 = $this->addField($e);

        //dd($this->getFields());

   /*     $field1->setName('field1 name');
        $field1->setDescription('field1 description');
        $field1->setType((new \Core\Type\Ui())->setName('testType 3'));*/

/*        $field2 = $this->addField(new \Core\Page\Form\Element());
        $field2->setName('field2 name');
        $field2->setDescription('field2 description');
        $field2->setType( (new \Core\Type\Ui())->setName('testType 2'));

        $field3 = $this->addField(new \Core\Page\Form\Element());
        $field3->setName('field3 name');
        $field3->setDescription('field3 description');
        $field3->setType( ( new \Core\Type\Ui())->setName('testType 3'));*/



    }
}
