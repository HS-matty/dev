<?php


namespace Page\Catalog;
use Core\Request;
use Core\Std;
use Core\Ui\Element\Field;

class Form extends \Core\Web\Form
{

    public function __construct()
    {
        $this->setName('Catalog Record');
        $this->setTitle('Catalog Record');
        $this->setDescription('Catalog Record');
        $this->setBody((new Std('<h1>Item body</h1>')));


        //dd(Request::inputString('popup'));
        if(Request::inputString('popup')) $this->setIsSingleTrue();
        else $this->setIsSingle(false);

        $id = Request::inputNumber('id');

        $csv = \Core\Type\File\Csv::load('export.csv',0,$id);

        //dd($)
        foreach ($csv->getHeader() as $key=>$header){
            $field = new Field();
            $field->setName($header)->setTitle($header)->setValue($csv->getData()->get(0)[$key]);
            $this->addField($field);

        }
    }
}