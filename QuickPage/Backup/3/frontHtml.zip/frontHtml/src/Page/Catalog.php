<?php
namespace Page;

use Core\Request;
use Core\Web;
use Core\Ui\Element;
use League\Csv\Reader;
use Local\Config;


class Catalog extends \Core\Web\Page
{
    public function __construct(){

        $this->setName('Catalog');
        $this->setTitle('Catalog');
        $this->setDescription('Catalog');

        $grid = new Web\Grid();
        $grid->setName('grid');
        //

        $page = (int) Request::input('p')->int();
        //load the CSV document from a file path
/*        $csv = Reader::createFromPath(Config::rootDir().'/local/csv/b_iblock_element.csv', 'r');
        $csv->setHeaderOffset(0);

        $header = $csv->getHeader(); //returns the CSV header record
        $records = $csv->getRecords();


        $allowedNames = ["ID","TIMESTAMP_X","MODIFIED_BY","DATE_CREATE","CREATED_BY","ACTIVE","ACTIVE_FROM","ACTIVE_TO","SORT","NAME","PREVIEW_PICTURE","PREVIEW_TEXT","PREVIEW_TEXT_TYPE","DETAIL_PICTURE"];;*/

        //$allowedNames = [ 'IE_XML_ID','IE_NAME', 'IE_ID', 'IE_ACTIVE', 'IE_ACTIVE_FROM','IE_ACTIVE_TO','IE_PREVIEW_PICTURE','IE_PREVIEW_TEXT','IE_PREVIEW_TEXT_TYPE','IE_DETAIL_PICTURE','IE_DETAIL_TEXT','IE_DETAIL_TEXT_TYPE','IE_CODE','IE_SORT','IE_TAGS','IP_PROP29', 'IP_PROP137','IP_PROP34','IP_PROP35', 'IP_PROP99','IP_PROP100','IP_PROP30', 'IP_PROP80','IP_PROP78','IP_PROP31','IP_PROP77','IP_PROP84','IP_PROP41','IP_PROP136','IP_PROP43','IP_PROP176','IP_PROP178','IP_PROP138','IP_PROP139','IP_PROP180','IP_PROP44','IC_GROUP0','IC_GROUP1','IC_GROUP2'];
        $allowedNames = [0=>'IE_XML_ID',1=>'IE_NAME',2=>'IE_ID',3=>'IE_ACTIVE',4=>'IE_ACTIVE_FROM',5=>'IE_ACTIVE_TO',6=>'IE_PREVIEW_PICTURE',7=>'IE_PREVIEW_TEXT'];
        $grid->setAllowedNames($allowedNames);

        //$csv = new \Core\Type\File\Csv();
        $csv = \Core\Type\File\Csv::load('export.csv',$page);


        foreach ($csv->getHeader() as $h){

            if(!in_array($h,$allowedNames)) continue;
            $field = $grid->addField();
            $field->setName($h)->setTitle($h);
            $this->addUiElement($grid);

        }

        $collection = $csv->getData();
        $dataset = new Web\Grid\Dataset();
        $dataset->setName('grid');
        $dataset->setCollection($collection);

        $grid->setDataset($dataset);

    }



}