<?php
namespace App;

use \Illuminate\Database\Eloquent\Model as EloquentModel;

class Model extends EloquentModel
{
    protected $fillable = ["name", "title", "value"];


    public function __construct(array $attributes = array())
    {
        parent::__construct($attributes);
        $this->initModel();

    }
    public function initModel(){

    }
    public function addFillable($array){
        $this->fillable = array_merge($this->fillable,$array);
        return $this;
    }

}


