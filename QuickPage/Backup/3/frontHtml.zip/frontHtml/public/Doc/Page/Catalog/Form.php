<?php
/* @var $form \Page\Catalog\Form */

$form = new \Page\Catalog\Form();

?>
<div class="row bounceInRight">
    <div class="one whole padded">

        <h2><? echo $form->getName(); ?></h2>

        <form action="#" method="post">
            <fieldset>
                <legend><? echo $form->getTitle(); ?></legend>


                <? foreach ($form->getFields()->collection() as $field) { ?>
                    <div class="row">

                        <div class="one whole padded">
                            <label for="name"><? echo $field->getTitle(); ?></label>
                            <input id="name" readonly="readonly" type="text" value="<? echo $field->getValue() ?>"
                                   placeholder="<? echo $field->getDescription(); ?>">
                        </div>
                    </div>
                <? } ?>

            </fieldset>
        </form>
    </div>
</div>
