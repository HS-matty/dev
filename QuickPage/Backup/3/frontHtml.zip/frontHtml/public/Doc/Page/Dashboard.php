<?php
?>
<article class="row">
    <div class="one sixth three-up-small-tablet two-up-mobile padded bounceInLeft animated"><a href="http://via.placeholder.com/900x500/2ecc71/ffffff/&amp;text=Image+1" title="View Larger Image" class="block green"><img src="http://via.placeholder.com/300x300/2ecc71/ffffff/&amp;text=Image+1" alt="Image 1" class="round"></a></div>
    <div class="one sixth three-up-small-tablet two-up-mobile padded rotateInDownLeft animated"><a href="http://via.placeholder.com/900x500/3498db/ffffff/&amp;text=Image+2" title="View Larger Image" class="block blue"><img src="http://via.placeholder.com/300x300/3498db/ffffff/&amp;text=Image+2" alt="Image 2"></a></div>
    <div class="one sixth three-up-small-tablet two-up-mobile padded bounceInDown animated"><a href="http://via.placeholder.com/900x500/9b59b6/ffffff/&amp;text=Image+3" title="View Larger Image" class="block purple"><img src="http://via.placeholder.com/300x300/9b59b6/ffffff/&amp;text=Image+3" alt="Image 3"></a></div>
    <div class="one sixth three-up-small-tablet two-up-mobile padded bounceInUp animated"><a href="http://via.placeholder.com/900x500/f1c40f/ffffff/&amp;text=Image+4" title="View Larger Image" class="block yellow"><img src="http://via.placeholder.com/300x300/f1c40f/ffffff/&amp;text=Image+4" alt="Image 4"></a></div>
    <div class="one sixth three-up-small-tablet two-up-mobile padded rotateInUpRight animated"><a href="http://via.placeholder.com/900x500/e67e22/ffffff/&amp;text=Image+5" title="View Larger Image" class="block orange"><img src="http://via.placeholder.com/300x300/e67e22/ffffff/&amp;text=Image+5" alt="Image 5"></a></div>
    <div class="one sixth three-up-small-tablet two-up-mobile padded bounceInRight animated"><a href="http://via.placeholder.com/900x500/e74c3c/ffffff/&amp;text=Image+6" title="View Larger Image" class="block red"><img src="http://via.placeholder.com/300x300/e74c3c/ffffff/&amp;text=Image+6" alt="Image 6"></a></div>
</article>

<!--form action="#" method="post">
  <fieldset>
    <legend>Example HTML5 Form</legend>
    <div class="row">
      <div class="one half padded">
        <label for="name">Text Field</label>
        <input id="name" type="text" placeholder="First & Last Name">
      </div>
      <div class="one half padded">
        <label for="email">Email Field</label>
        <input id="email" type="email" placeholder="you@example.com">
      </div>
    </div>
    <div class="row">
      <div class="one whole padded">
        <label for="address">Address</label>
        <input id="address" type="text" placeholder="Street Address">
      </div>
    </div>
    <div class="row">
      <div class="two fourths padded">
        <input type="text" placeholder="City">
      </div>
      <div class="one fourth padded"><span class="select-wrap">
          <select class="unselected">
            <option value="" disabled="" selected="">State</option>
            <option value="AL">Alabama</option>
            <option value="AK">Alaska</option>
            <option value="YT">Yukon Territory</option>
          </select></span></div>
      <div class="one fourth padded">
        <input type="text" placeholder="Zip Code">
      </div>
    </div>
    <div class="row">
      <div class="one whole padded">
        <label for="message">Special Instructions</label>
        <textarea id="message" placeholder="Enter your message..."></textarea>
      </div>
    </div>
    <div class="row">
      <div class="one whole pad-left">
        <label for="twitter">Prefixed & Suffixed</label>
      </div>
    </div>
    <div class="row">
      <div class="one half padded">
        <div class="row">
          <div class="one mobile sixth"><span class="prefix">@</span></div>
          <div class="five mobile sixths">
            <input id="twitter" type="text" name="twitter" placeholder="twitter handle">
          </div>
        </div>
      </div>
      <div class="one half padded">
        <div class="row">
          <div class="three mobile fifths">
            <input type="text" name="sidereel" placeholder="desired username">
          </div>
          <div class="two mobile fifths"><span class="suffix">@example.com</span></div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="one whole padded">
        <label for="thing1">Radio Buttons:</label>
        <ul class="unstyled zero">
          <li>
            <input id="thing1" type="radio" name="things" checked="">
            <label for="thing1" class="inline">Thing one</label>
          </li>
          <li>
            <input id="thing2" type="radio" name="things">
            <label for="thing2" class="inline">Thing two</label>
          </li>
        </ul>
      </div>
    </div>
    <div class="row">
      <div class="one whole padded">
        <input id="allthings" type="checkbox" name="things" checked="">
        <label for="allthings" class="inline"> I want all the things!</label>
      </div>
    </div>
  </fieldset>
</form-->
<!-- END_FORM-->
<!-- GRID-->
<br / ><br / >


<!-- END_GRID-->


