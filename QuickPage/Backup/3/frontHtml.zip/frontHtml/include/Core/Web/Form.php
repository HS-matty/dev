<?php

namespace Core\Web;
use Core\CollectionTrait;
use Core\Web;
use Core\Std;

class Form extends \Core\Ui\Element
{

    public function __construct(){

        $this->setTitle('Form Title')->setName('Form')->setType('Form');
        $this->setDescription('Form Description');
        $this->setBody((new \Core\Type\Content\Html())->setValue('<h1>THIS IS HTML OUTPUT</h1>'));

    }


}