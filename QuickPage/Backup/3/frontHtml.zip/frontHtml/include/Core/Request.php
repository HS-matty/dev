<?php

namespace Core;


class Request extends Std
{

    /**
     * @param $name
     * @return Std
     */
    public static function input($name){


        return (new Std())->setValue(@$_REQUEST[$name]);
    }

    public static function inputNumber($name){
        return (int) self::input($name)->asString();
    }

    public static function inputString($name){
        return (string) self::input($name)->asString();
    }
}