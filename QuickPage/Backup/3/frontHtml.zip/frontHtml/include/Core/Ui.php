<?php


namespace Core;


class Ui extends Std
{

   // public fun

}