<?php


namespace Core\Type\Ui;


class Form
{

}