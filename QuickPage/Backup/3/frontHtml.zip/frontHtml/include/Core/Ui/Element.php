<?php


namespace Core\Ui;

use Core\CollectionTrait;
use Core\Std;

class Element extends Std
{

    protected bool $isSingle = false;
    protected $body;

    /**
     * @return bool
     */
    public function isSingle(): bool
    {
        return $this->isSingle;
    }

    /**
     * @param bool $isSingle
     */
    public function setIsSingle(bool $isSingle): void
    {
        $this->isSingle = $isSingle;
    }

    public function setIsSingleTrue(){
        $this->setIsSingle(true);
    }


    /**
     * @return Std
     */
    public function getBody()
    {
        return $this->body;
    }

    /**
     * @param mixed $body
     */
    public function setBody(Std $body)
    {
        $this->body = $body;
    }

    use CollectionTrait;
    /**
     * @param Element\Field $field
     * @return Element\Field
     */
    public function addField(Element\Field $field = null){
        if(!$field) $field = new Element\Field();
        $this->collectionAdd($field);
        return $field;
    }

    /**
     * @return \Core\Collection
     */
    public function getFields(){
        return $this->collection();
    }
}