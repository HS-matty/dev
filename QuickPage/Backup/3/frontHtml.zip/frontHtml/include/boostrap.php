<?php
// written by myw.php_sergey@v3-club.minsk.by (21-09-2020)

error_reporting(E_ALL);
ini_set('display_errors',1);

require_once '../vendor/autoload.php';
//loadin not psr files, but we get psr now ;D
//require_once 'core/_core_autoload.php';
$rootDir  = dirname(__DIR__, 1);

\Local\Config::setaRootDir($rootDir);
\Local\Config::setaHostName($_SERVER['HTTP_HOST']);


\Core\Loader::setDocumentRoot($rootDir);

require_once ('Local/Config/Static/Db.php');

require_once("database.php");


///thnx to stackoverflow
$app = new Illuminate\Container\Container();
Illuminate\Support\Facades\Facade::setFacadeApplication($app);

$app->singleton('db', function () use ($app) {
    $capsule = new Illuminate\Database\Capsule\Manager;

    $capsule->addConnection([
        'driver'    => 'mysql',
        'host'      => 'localhost',
        'database'  => 'app',
        'username'  => 'root',
        'password'  => 'root',
        'charset'   => 'utf8',
        'collation' => 'utf8_unicode_ci',
        'prefix'    => '',
    ]);

    $capsule->setAsGlobal();
    $capsule->bootEloquent();

    return $capsule;
});

/*$app->singleton('hash', function () use ($app) {
    return new Illuminate\Hashing\HashManager($app);
});*/

class_alias(Illuminate\Support\Facades\DB::class, 'DB');


//class_alias(Illuminate\Support\Facades\Hash::class, 'Hash');

//Boot Database Connection
//new Database();
//use Illuminate\Support\Facades\DB as DB;
//dd(\DB::connection());