<?php

namespace Local;
class Config extends \Core\Std
{
    protected static $proto = 'http://';
    protected static $hostName = '';
    protected static $rootDir;

    public static function setaHostName($hostname){
        self::$hostName = $hostname;
    }

    public static function setaRootDir($rootDir){
        self::$rootDir = $rootDir;
    }

    public static function hostname(){
        return self::$proto.self::$hostName;
    }

    public static function rootDir(){
        return self::$rootDir;
    }

    public static function srcDir(){
        return self::rootDir().'/src';
    }
    public static function srcTemplateDir(){
        return self::srcDir().'/Template';
    }

    public static function publicDir(){
        return self::rootDir().'/public';
    }




}