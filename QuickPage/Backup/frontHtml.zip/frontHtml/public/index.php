<?php

require_once('../include/boostrap.php');

use \Core\Request as Request;
use \Core\Globals as G;
use \Local\Config as Config;

use Illuminate\Support\Facades\DB;

//dd(DB::connection());
//$page = $request->input('page');

/*@todo validate*/
//$pageName = ucfirst(strtolower(substr(Request::input('page')->asString(),10)));
$pageName = ucfirst(substr(Request::input('page')->asString(), 0, 15));

$pageFile = null;
if ($pageName) {
    $pageFile = 'Doc/Page/' . $pageName . '.php';
    //DD($pageFile);
    if (!file_exists($pageFile)) $pageFile = $pageFile = 'Doc/Page/Dashboard.php';
} else $pageName = 'Dashboard';

//\Core\Loader::requireClass('\Page\Dashboard');

$pageClassName = "\\Page\\" . $pageName;

//dd($pageClassName);
$page = new $pageClassName;


$form = new \Page\Dashboard\TestForm();


//dd(json_decode($request->getContent(), true));

?>
<html>

<head>
    <title><?php echo $page->getTitle(); ?></title>
    <!-- Modernizr -->
    <script src="/js/libs/modernizr-2.6.2.min.js"></script>
    <!-- framework css -->
    <!--[if gt IE 9]><!-->
    <link type="text/css" rel="stylesheet" href="/css/groundwork.css">
    <!--<![endif]-->
    <!--[if lte IE 9]>
    <link type="text/css" rel="stylesheet" href="/css/groundwork-core.css">
    <link type="text/css" rel="stylesheet" href="/css/groundwork-type.css">
    <link type="text/css" rel="stylesheet" href="/css/groundwork-ui.css">
    <link type="text/css" rel="stylesheet" href="/css/groundwork-anim.css">
    <link type="text/css" rel="stylesheet" href="/css/groundwork-ie.css">
    <![endif]-->
</head>

<body>

<header>
    <div class="container">
        <div class="row">
            <div class="one half">
                <h1 class="quicksand">QuickPage</h1></div>
            <div class="one half"></div>
        </div>
    </div>
</header>

<!--  NAVIGATION -->
<div class="container">
    <nav class="nav gap-top" title="Menu" style="padding-left:10px">
        <div class="row">
            <div class="one half">
                <ul role="menubar">
                    <li><a href="<? echo Config::hostName() ?>?page=Dashboard">Dashboard</a></li>
                    <li><a href="<? echo Config::hostName() ?>?page=Catalog">Catalog</a></li>
                    <li><a href="<? echo Config::hostName() ?>?page=Managers">Managers</a></li>

                </ul>
            </div>
        </div>

    </nav>
</div>
<!--  END_NAVIGATION -->


<!--  BODY -->


<div class="container">
    <div class="row">

        <div class="row" style="padding:15px">
            <div class="three fifths bounceInRight ">
                <h1 class="zero museo-slab"><h2><? echo $page->getTitle() ?></h2>
                    <p class="quicksand"><? echo $page->getDescription() ?></p>
            </div>
            <div class="two fifths align-right-ipad align-right-desktop flipInX animated">
                <p class="quicksand">Example Layout 1 of 4</p>
                <p><a href="home.html" rel="prev" class="blue button">Back</a> <a href="layout-b.html" rel="next"
                                                                                  class="green button">Next: Image
                        Gallery </a></p>
            </div>

        </div>

        <!--p class="success message">This is a success message.</p-->
        <hr/>

        <div class="container">
            <div class="row">
                <?php
                if ($pageFile) require_once($pageFile);
                else echo '<h1>Not Found</h1>';
                ?>
            </div>
        </div>

        <!--div id="message">
            <h3>TestMessage</h3>
        </div>


        <h1>Hello</h1>
        <button class="success">Success</button -->

    </div>
</div>


<script type="text/javascript" src="/js/libs/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="/js/groundwork.all.js"></script>

<!--  BODY -->

<footer class="gap-top bounceInUp">
    <div class="box square">
        <div class="container padded">
            <div class="row">
                <div class="one half padded">
                    Powered by QuickPage and PowerGroundworkCSS
                </div>
            </div>
        </div>
</footer>


</body>
</html>