<?php
?>

 <form action="#" method="post">
                <fieldset>
                    <legend>123<? echo $form->getTitle();?></legend>
<div class="row">
    <? foreach($form->getFields() as $field) { ?>
        <div class="one half padded">
            <label for="name"><? echo $field->getTitle();?></label>
            <input id="name" type="text" placeholder="<? echo $field->getDescription();?>">
        </div>
    <? }?>
</div>
</fieldset>
</form>
