<?php

namespace Local;
class Config extends \Core\Std
{
    protected static $proto = 'http://';
    protected static $hostName = '';
    protected static $rootDir;

    public static function setaHostName($hostname){
        self::$hostName = $hostname;
    }

    public static function setaRootDir($rootDir){
        self::$rootDir = $rootDir;
    }

    public static function hostname(){
        return self::$proto.self::$hostName;
    }



}