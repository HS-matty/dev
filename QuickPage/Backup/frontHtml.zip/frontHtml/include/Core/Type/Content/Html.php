<?php


namespace Core\Type\Content;


use Core\Std;

class Html extends Std
{

}