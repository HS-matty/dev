<?php


namespace Core;
use \Illuminate\Support\Collection as ICollection;

class Collection extends Std
{

    /**
     * @var ICollection
     */
    protected $collection;

    /**
     * Collection constructor.
     * @param
     */
    public function __construct(\Illuminate\Support\Collection $collection = null)
    {
        if($collection) $this->setCollection($collection);
    }



    /**
     * @return ICollection
     */
    public function getCollection()
    {
        if(!$this->collection) $this->initCollection();
        return $this->collection;
    }
    protected function initCollection(){
        $this->collection = new ICollection();
    }

    /**
     * @param ICollection $collection
     */
    public function setCollection($collection)
    {
        $this->collection = $collection;
    }

    /**
     * @param $element
     * @return Collection
     */
    public function add($element){

        $this->getCollection()->add($element);

        return $this;
    }

    /**
     * @return ICollection
     */
    public function collection(){
        return $this->collection;
    }

}