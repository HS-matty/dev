<?php

namespace Core;


class Request extends Std
{

    /**
     * @param $name
     * @return Std
     */
    public static function input($name){


        return (new Std())->setValue(@$_REQUEST[$name]);
    }
}