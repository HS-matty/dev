<?php


namespace Core\Ui\Element;


use Core\Ui\Element;

class Field extends Element
{

}