<?php


namespace Core;


class Globals extends Std
{

    public static function hostName(){
        return 'http://127.0.0.1';
    }
}