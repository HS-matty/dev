<?php


namespace Core\Web;

use Core\Ui\Element;

/**
 * Class Page
 * @package Core
 */
class Page extends Element
{

    public function __construct(){
        $this->setTitle('Page Title');
        $this->setDescription('Page Description');
        $this->setBody((new \Core\Type\Content\Html())->setValue('<h1>THIS IS HTML OUTPUT</h1>'));
        $this->setType('Page');
    }

    public function addMenu(\stdClass $menu){
        return $this->collection()->add($menu);
    }

    public function addUiElement(Element $element){
        $this->collectionAdd($element);
        return $this;
    }

    public function getUiElements(){
        return $this->collection()->collection()->all();
    }

    public function getUiElement($name){
        $found = false;
        /* @var $element Element */
        foreach ($this->getUiElements() as $element){
            if($element->getName() == $name) {
                $found = $element;
                break;
            }
        }
        return $found;

    }



}