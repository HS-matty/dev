<?php


namespace Core\Web;


use Core\Web\Grid\Dataset;

class Grid extends \Core\Ui\Element
{
    protected $dataset;

    public function __construct(){
        $this->setTitle('Grid Title')->setName('Grid')->setType('Grid');
        $this->setDescription('Grid Description');
        $this->setBody((new \Core\Type\Content\Html())->setValue('<h1>THIS IS HTML OUTPUT</h1>'));
    }

    /**
     * @return Dataset | NULL
     */
    public function getDataset(){
        return $this->dataset;
    }

    /**
     * @param Dataset $dataset
     * @return Dataset
     */
    public function setDataset(Dataset $dataset){
         return $this->dataset = $dataset;
    }
}