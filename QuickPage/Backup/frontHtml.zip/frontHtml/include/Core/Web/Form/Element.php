<?php

namespace Core\Web\Form;

use Core\Std;

class Element extends Std
{

}