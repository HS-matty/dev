<?php
?>

<h2>Latest News</h2>
<table class="responsive" data-max="15">
    <thead>
    <tr>
        <th>Table Heading</th>
        <th>Table Heading</th>
        <th>Table Heading</th>
        <th>Table Heading</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>Table cell</td>
        <td>Table cell</td>
        <td>Table cell</td>
        <td>Table cell</td>
    </tr>
    </tbody>
    <tfoot>
    <tr>
        <td>Footer cell</td>
        <td>Footer cell</td>
        <td>Footer cell</td>
        <td>Footer cell</td>
    </tr>
    </tfoot>
</table>