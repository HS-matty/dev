<?php


namespace Page;


class Managers extends \Core\Page
{
    public function __construct(){
        $this->setName('Managers');
        $this->setTitle('Managers');
        $this->setDescription('Managers');

    }



}