<?php


namespace Page;

use Core\Web;
use Core\Ui\Element;

class Catalog extends \Core\Web\Page
{
    public function __construct(){

        $this->setName('Catalog!!!')->setTitle('Catalog!!!')->setDescription('Catalog!!');

        $grid = new Web\Grid();
        $grid->setName('grid');

        $field1 = $grid->addField();
        $field1->setName('id')->setTitle('Id');



        $field2 = $grid->addField();
        $field2->setName('name')->setTitle('Name');

        $field3 = $grid->addField();
        $field3->setName('value')->setTitle('Value');

        $this->addUiElement($grid);

        $dataset = new Web\Grid\Dataset();
        $dataset->setName('grid');

        $row1 = ['id'=>1,'name'=>'row1-name','value'=>'row1-value'];
        $row2 = ['id'=>2,'name'=>'row2-name','value'=>'row2-value'];
        $row3 = ['id'=>3,'name'=>'row3-name','value'=>'row3-value'];

        $data = [$row1,$row2,$row3];
        $dataset->setData($data);
        $grid->setDataset($dataset);

    }



}