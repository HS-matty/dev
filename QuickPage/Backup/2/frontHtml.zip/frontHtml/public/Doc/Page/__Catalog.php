<?php
use \Core\Web\Page;
/* @var $page Page */
/* @var $grid Core\Web\Grid */


$grid = $page->getUiElement('grid');
//dd($grid->getFields()->collection());
foreach ($grid->getFields() as $field){
    echo $field->getName();
}
?>
<?php
if(!$grid){
    echo 'No grid found';
}
?>
<br />
<h3><? echo $grid->getTitle(); ?></h3>
<table class="responsive" data-max="15">
    <thead>
    <tr>

        <? foreach ($grid->getFields()->collection() as $field): ?>
            <th><? echo $field->getTitle();?></th>
        <? endforeach; ?>


    </tr>
    </thead>
    <tbody>
    <?  $dataset = $grid->getDataset(); ?>

    <? foreach ($dataset->getData()->all() as $row): ?>
    <tr>
        <? foreach ($row as $rowValue): ?>
        <td><? echo $rowValue;?></td>
        <? endforeach; ?>
    </tr>
    <? endforeach; ?>
    </tbody>
    <!--tfoot>
    <tr>
        <td>Footer cell</td>
        <td>Footer cell</td>
        <td>Footer cell</td>
        <td>Footer cell</td>
    </tr>
    </tfoot-->
</table>



