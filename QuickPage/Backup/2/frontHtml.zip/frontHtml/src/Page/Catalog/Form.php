<?php


namespace Page\Catalog;
use Core\Request;
use Core\Std;
use Core\Ui\Element\Field;

class Form extends \Core\Web\Form
{

    public function __construct()
    {
        $this->setName('Catalog Record');
        $this->setTitle('Catalog Record');
        $this->setDescription('Catalog Record');
        $this->setBody((new Std('<h1>Item body</h1>')));
        $this->setIsSingleTrue();

        $id = Request::inputNumber('id');

        $csv = \Core\Type\File\Csv::load('export.csv',0,$id);

        //dd($)
        foreach ($csv->getHeader() as $key=>$header){
            $field = new Field();
            $field->setName($header)->setTitle($header)->setValue($csv->getData()->get(0)[$key]);
            $this->addField($field);

        }


        /*$field2 = new Field();
        $field2->setName('field2-name')->setTitle('Field2-title')->setValue('12311114');
        $this->addField($field2);*/
        //dd($this->getFields());


    }
}