<?php

define("DBDRIVER","mysql");
define("DBHOST","localhost");
define("DBNAME","app");
define("DBUSER","root");
define("DBPASS","root");