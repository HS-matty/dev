<?php


namespace Core;


class Registry extends Std
{

    protected static $container = [];

    public static function set($name,$value){
        self::$container[$name] = $value;
    }

    public function get($name){
        return @self::$container[$name];
    }

}