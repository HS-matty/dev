<?php


namespace Core;

trait CollectionTrait
{
    /**
     * @var Collection
     */
    protected $collection;

    /**
     * @param $item
     * @return Collection
     */
    public function collectionAdd($item){
        $this->collection()->add($item);
        return $this->collection();
    }

    /**
     * @return Collection
     */
    public function collection(){
        if(!$this->collection) $this->collection = new Collection();
        return $this->collection;
    }


}