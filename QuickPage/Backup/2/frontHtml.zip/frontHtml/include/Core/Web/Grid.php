<?php


namespace Core\Web;


use Core\Web\Grid\Dataset;

class Grid extends \Core\Ui\Element
{


    protected $header;
    protected $dataset;

    protected $allowedNames;

    public function __construct(){
        $this->setTitle('Grid Title')->setName('Grid')->setType('Grid');
        $this->setDescription('Grid Description');
        $this->setBody((new \Core\Type\Content\Html())->setValue('<h1>THIS IS HTML OUTPUT</h1>'));
    }


    /**
     * @return mixed
     */
    public function getAllowedNames()
    {
        return $this->allowedNames;
    }

    /**
     * @param mixed $allowedNames
     */
    public function setAllowedNames($allowedNames): void
    {
        $this->allowedNames = $allowedNames;
    }

    public function inAllowedNames($name){
        return in_array($name,$this->allowedNames);
    }

    public function inAllowedNamesByKey($key){
        return isset($this->allowedNames[$key]);
    }



    /**
     * @return Dataset | NULL
     */
    public function getDataset(){
        return $this->dataset;
    }

    /**
     * @param Dataset $dataset
     * @return Dataset
     */
    public function setDataset(Dataset $dataset){
         return $this->dataset = $dataset;
    }
}