<?php


namespace Core\Type\File;

use Core\Std;
use Illuminate\Support\Collection;
use League\Csv\Reader;
use Local\Config;

class Csv extends Std
{

    const ROWS_PER_PAGE = 10;
    protected $header;
    protected $data;
    protected $allowedNames;


    public function __construct()
    {
    }

    /**
     * @return Collection
     */
    public function getHeader()
    {
        return $this->header;
    }

    /**
     * @param mixed $header
     */
    public function setHeader($header)
    {
        $this->header = $header;
    }

    /**
     * @return Collection
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * @param mixed $data
     */
    public function setData($data)
    {
        $this->data = $data;
    }


    public static function loadRecord($id)
    {
        // ..
    }


    /**
     * @param $file
     * @return Csv
     */
    public static function load($file, $page = 0,$offset = 0)
    {

        // $csv = Reader::createFromPath(Config::rootDir().'/local/csv/'.$file, 'r');
        ///stack
        ///
        $o = new self();
        $handle = fopen(Config::rootDir() . '/local/csv/' . $file, "r");
        $data = [];

        for ($i = 0; $row = fgetcsv($handle); ++$i) {
            if ($i == 0) {
                $o->setHeader(collect($row));
                continue;
            } else {
                if ($i >= ($page * self::ROWS_PER_PAGE) && $i <= ($page * self::ROWS_PER_PAGE + self::ROWS_PER_PAGE)){
                    if($offset && $i != $offset) continue;
                    $row['__offset'] = $i;
                    $data[] = $row;
                } elseif ($i >= ($page + self::ROWS_PER_PAGE)) break;

            }
        }

        $o->setData(collect($data));
        fclose($handle);

        return $o;
    }


}